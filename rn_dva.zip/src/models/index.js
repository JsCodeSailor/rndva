import appModel from "./app";

export default [appModel];
