// import { toastHandler } from '../utils';
export default {
	namespace: "test",
	state: {
		count: 1,
	},
	reducers: {
		Decrease(state) {
			return { ...state, count: state.count - 1 };
		},
		Increase(state) {
			return { ...state, count: state.count + 1 };
		},
	},
};
