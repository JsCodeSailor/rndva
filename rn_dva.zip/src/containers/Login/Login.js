import React, { Component, Fragment } from "react";
import { Text, View, Button } from "react-native";
import { SafeAreaView } from "react-navigation";
import { connect } from "react-redux";
@connect((state) => ({
	count: state.test.count,
}))
class Login extends React.PureComponent {
	onIncrease = () => {
		const { dispatch, count, navigation } = this.props;
		if (count === 3) {
			navigation.navigate("Home");
		}
		dispatch({
			type: "test/Increase",
		});
	};
	onDecrease = () => {
		const { dispatch } = this.props;
		dispatch({
			type: "test/Decrease",
		});
	};
	render() {
		const { count } = this.props;
		return (
			<View style={{ flex: 1, flexDirection: "column" }}>
				<View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
					<Text style={{ fontSize: 20 }}>点击次数:{count}</Text>
				</View>
				<View style={{ height: 50 }}>
					<View style={{ flex: 1, flexDirection: "row" }}>
						<View style={{ flex: 1, padding: 5 }}>
							<Button title={"+"} onPress={this.onIncrease} />
						</View>
						<View style={{ flex: 1, padding: 5 }}>
							<Button title={"-"} onPress={this.onDecrease} />
						</View>
					</View>
				</View>
			</View>
		);
	}
}

export default Login;
