import React, { Component, Fragment } from "react";
import { Text, View, Button } from "react-native";
import { SafeAreaView } from "react-navigation";
import { connect } from "react-redux";

class Home extends React.PureComponent {
	render() {
		const { count } = this.props;
		return (
			<View style={{ flex: 1, flexDirection: "column" }}>
				<Text style={{ fontSize: 20 }}>HOME</Text>
			</View>
		);
	}
}

export default Home;
