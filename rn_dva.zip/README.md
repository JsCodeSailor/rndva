1.在rn_dva目录下执行cmd npm install 写入依赖包
2.在执行react-native link 
3.在执行 react-natvice run-android
